import java.util.*;

public class Q67{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        int n = sc.nextInt();
        for(int i=0; i<n;i++, System.out.println()){
            int num = 1;

            for(int j=0;j<=i;j++){
                System.out.print(num+"");
                num += 2;
            }
            
        }
    }
}