import java.util.Scanner;
public class Q23 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int i=0;
        for(; i<n;){
            System.out.println(i);
            i++;
        } 

    }
    
    
}
