import java.util.Scanner;
public class Q19 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("infinite loop example");
        for (int i = 0; ; i++) {
            System.out.println("iteration: " + i);
        }
        
    }
    
}
