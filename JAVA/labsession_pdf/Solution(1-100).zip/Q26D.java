import java.util.Scanner;
public class Q26D {
    public static void main(String[] args) {
        int number = 5;
        int result = square(number);
        System.out.println("The square of " + number + " is: " + result);
    }
    public static int square(int number) {
        return number * number;
    }
    
}
