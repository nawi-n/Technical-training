import java.util.*;
public class Q73 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int max = Collections.max(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9));
        System.out.println("----------"+ max);
    }
    
}
