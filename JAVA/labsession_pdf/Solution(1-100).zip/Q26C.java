import java.util.Scanner;
public class Q26C {
    public static void main(String[] args) {
        int result = getNumber();
        System.out.println("The number is: " + result);

    }
    public static int getNumber() {
        return 42; 
    }
    
}
