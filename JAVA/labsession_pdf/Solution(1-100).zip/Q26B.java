import java.util.Scanner;
public class Q26B {
    public static void main(String[] args) {
        String name = "nawin";
        greetUser(name);    
    }
    public static void greetUser(String name) {
        System.out.println("Hello, " + name + "!");
        System.out.println("function without return type and with parameters.");
    }


    
}