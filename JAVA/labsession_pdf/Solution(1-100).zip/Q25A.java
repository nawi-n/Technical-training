import java.util.Scanner;
public class Q25A {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int i =0;
        do{
            System.out.println("Welcome to the do while loop!");
            i++;
        }while(i<n);

    }
    
}
