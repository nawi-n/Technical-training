import java.util.Scanner;
public class Q26A {
    public static void main(String[] args) {
        greetUser();    
    }
    public static void greetUser() {
        System.out.println("function without return type and without parameters.");
    }


    
}
