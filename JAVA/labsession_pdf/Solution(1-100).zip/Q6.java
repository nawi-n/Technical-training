import java.util.*;

public class Q6{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n1 = sc.nextInt();
        int n2 = sc.nextInt();
        System.out.println(n1<n2? "True":"False");
        System.out.println(n1>n2? "True":"False");
        System.out.println(n1==n2? "True":"False");
        System.out.println(n1<=n2? "True":"False");
        System.out.println(n1>=n2? "True":"False");
        System.out.println(n1!=n2? "True":"False");
        sc.close();
    }
}