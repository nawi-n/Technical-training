import java.util.*;
public class Q75 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Integer[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        List<Integer> list = Arrays.asList(arr);
        Collections.reverse(list);
        System.out.println("Reversed Array: " + list);
        // Print the reversed array 


    }
    
}
